-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ems
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ad_login`
--

DROP TABLE IF EXISTS `ad_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ad_login` (
  `ad_id` varchar(25) NOT NULL,
  `Password` varchar(10) NOT NULL,
  `name` varchar(15) NOT NULL,
  PRIMARY KEY (`ad_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ad_login`
--

LOCK TABLES `ad_login` WRITE;
/*!40000 ALTER TABLE `ad_login` DISABLE KEYS */;
INSERT INTO `ad_login` VALUES ('admin1@gmail.com','admin1',''),('admin2@gmail.com','admin2',''),('admin3@gmail.com','admin3','');
/*!40000 ALTER TABLE `ad_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_us`
--

DROP TABLE IF EXISTS `contact_us`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_us` (
  `name` varchar(15) NOT NULL,
  `email` varchar(25) NOT NULL,
  `contact_no` varchar(10) NOT NULL,
  `address` text NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_us`
--

LOCK TABLES `contact_us` WRITE;
/*!40000 ALTER TABLE `contact_us` DISABLE KEYS */;
INSERT INTO `contact_us` VALUES ('Aakarshita','aakarshi@yahoo.com','8791523209','Aligarh','Concern about project details'),('Aarman ','aarman@gmail.com','8791425262','Aligarh','Hey'),('Arun Sharma','arunsharma@gmail.com','arun@gmail','Banglore','yo'),('jatin','jatin@gmail.com','8791546525','aligarh','yo bro'),('kush','kush@gmail.com','8791523209','Aligarh','concern about project details'),('Mayank','mayankkr@gmail.com','9034345433','India','Test'),('Narendra Modi','modi@gmail.com','8791523209','Ramghat Road ,Aligarh','Project detail'),('Nandini Saxena','nandini@gmail.com','8791523209','Aligarh','Yo Bro '),('Neeraj sharma','neerajsh@gmail.com','7906535408','14/113, center point, aligarh\n','(:\n'),('Piyush Kumar','piyushkr@gmail.com','8791523209','Tamoli Para ,Aligarh','Invite me'),('Puneet agarwal ','puneetagarwal@gmail.com','8791526535','7 / 49, manik chowk , aligarh','Any vacancies is there.'),('Rishabh Kumar','rishabhkr@gmail.com','8791523209','Tamoli Para ,Aligarh','Invite me'),('Sakshi Saini','sakshi@gmail.com','8791523209','Aligarh','Yoo yoo'),('Testa','TEdst@gmail.com','9034345433','Testfff','Testf'),('Test','Test@gmail.com','9034345433','Test','Test'),('Testaaa','TEst343@gmail.com','9034345433','India','Testf');
/*!40000 ALTER TABLE `contact_us` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emp_leave`
--

DROP TABLE IF EXISTS `emp_leave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `emp_leave` (
  `name` varchar(20) DEFAULT NULL,
  `leave_from` varchar(30) DEFAULT NULL,
  `leave_to` varchar(30) DEFAULT NULL,
  `reason` varchar(40) DEFAULT NULL,
  `grant_leave` varchar(10) NOT NULL DEFAULT 'false'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emp_leave`
--

LOCK TABLES `emp_leave` WRITE;
/*!40000 ALTER TABLE `emp_leave` DISABLE KEYS */;
INSERT INTO `emp_leave` VALUES ('rishabhkr@gmail.com','2024-02-01','2024-02-02','Budget','Budget'),('rishabhkr@gmail.com','2024-02-04','2024-02-11','Travelling','false'),('rishabhkr@gmail.com','2024-02-10','2024-02-11','Travelling','false'),('rishabhkr@gmail.com','2024-02-11','2024-02-11','Fever','false'),('rishabhkr@gmail.com','2024-01-17','2024-01-24','TEst','false');
/*!40000 ALTER TABLE `emp_leave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emp_login`
--

DROP TABLE IF EXISTS `emp_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `emp_login` (
  `emp_id` varchar(25) NOT NULL,
  `Password` varchar(10) NOT NULL,
  PRIMARY KEY (`emp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emp_login`
--

LOCK TABLES `emp_login` WRITE;
/*!40000 ALTER TABLE `emp_login` DISABLE KEYS */;
INSERT INTO `emp_login` VALUES ('aakarshita@gmail.com','aakarshita'),('aakash@gmail.com','aakash'),('mayankkr@gmail.com','mayank'),('nandni@gmail.com','nandni'),('piyushkr@gmail.com','bharat'),('prashant@gmail.com','prashant'),('rishabhkr@gmail.com','rishabh'),('rosy@gmail.com','rosy'),('sakshi@gmail.com','sakshi');
/*!40000 ALTER TABLE `emp_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `first_name` varchar(15) NOT NULL,
  `last_name` varchar(15) NOT NULL,
  `age` int NOT NULL,
  `gender` char(6) NOT NULL,
  `email` varchar(25) NOT NULL,
  `address` text NOT NULL,
  `state` varchar(12) NOT NULL,
  `password` varchar(10) NOT NULL,
  `doj` varchar(10) NOT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES ('Aakarshita','Saini',20,'female','aakarshita@gmail.com','Ramghat Road, Aligarh','U.P.','aakarshita','13/09/1999'),('Aarman','shah',19,'on','aarman@gmail.com','','U.P.','aarman','2019-12-19'),('Abhi','Saxena',19,'on','abhi@gmail.com','','Rajasthan','abhi','2/23/2020'),('Anjali','Yadav',20,'on','anjali@yahoo.com','','Harayana','anjali','2/23/2020'),('Arun','Sharma',20,'on','arun@gmail.com','','Maharastra','arun','2020-03-01'),('Bharat','Bhardhwaj',20,'on','bharat@gmail.com','','up','bharat','2/23/2020'),('Mahendra singh','Dhoni',20,'on','dhoni@gmail.com','','West Bengal','dhoni','2020-03-01'),('Dileep','Goenka',19,'on','dileep@gmail.com','','Maharastra','dileep','2019-06-24'),('Harsh','Saxena',18,'on','harsh@gmail.com','','up','harsh','2020-03-15'),('Mayank','Kumar',20,'on','mayan@gmail.com','','delhi','may','2020-03-01'),('Mayank ','Kumar',22,'Male','mayankkr@gmail.com','15/144, Tamoli Para ,Aligarh','U.P.','mayank','5/4/2018'),('pari','Saxena',19,'on','pari@gmail.com','','Delhi','pari','2/23/2020'),('Piyush ','Kumar',19,'Male','piyushkr@gmail.com','15/144, Tamoli Para ,Aligarh','U.P.','piyush','2/2/20'),('Rajesh','Sharam',20,'on','rajesh@gmail.com','','M.P.','rajesh','2/23/2020'),('Rishabh ','Kumar',21,'Male','rishabhkr@gmail.com','15/144, Tamoli Para ,Aligarh','U.P.','rishabh','4/5/2019'),('rosy','Singh',19,'Female','rosy@gmail.com','Ramghat Road ,aligarh\n','U.P.','rosy','5/52020'),('Sakshi','Agarwal',19,'Female','sakshi@gmail.com','Bharadhwari ,aligarh','U.P.','sakshi','5/52020'),('Shalini','Saxena',18,'on','shalini@gmail.com','','Maharastra','shalini','2/23/2020'),('Test','Test',18,'male','Test@gmail.com','Test','Test','Test','2024-01-17'),('vin','diesel',18,'on','vin@gmail.com','','up','qwerty','2/23/2020'),('Virat ','Kohli',18,'on','viratkohli@gmail.com','','Delhi','virat','2020-03-02');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proj_works`
--

DROP TABLE IF EXISTS `proj_works`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proj_works` (
  `name` varchar(25) NOT NULL,
  `prroj_id` varchar(15) NOT NULL,
  `email` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`name`,`prroj_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proj_works`
--

LOCK TABLES `proj_works` WRITE;
/*!40000 ALTER TABLE `proj_works` DISABLE KEYS */;
/*!40000 ALTER TABLE `proj_works` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS `project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project` (
  `proj_id` varchar(8) NOT NULL,
  `Proj_time` varchar(100) NOT NULL,
  `Time` varchar(10) NOT NULL,
  `proj_type` varchar(20) NOT NULL,
  `proj_cate` varchar(20) NOT NULL,
  PRIMARY KEY (`proj_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project`
--

LOCK TABLES `project` WRITE;
/*!40000 ALTER TABLE `project` DISABLE KEYS */;
INSERT INTO `project` VALUES ('pro123','Swimming Management System','10 days','e-commerce','e-commerce'),('pro124','Employee Management System','5 days','ERP','ERP'),('pro125','Hotel Management System ','20 days','ERP','ERP'),('pro225','E-way Bill System','25 days','e-commerce','e-commerce'),('pro226','E-Bill System','25 days','ENterprise R.P.','ERP'),('pro227','Airline Management System','30 days','E-commerce','E-commerce'),('Pro333','Beacon','1 months','ERP','Dr. Aasim'),('Pro334','Beacon','1 months','ERP','ERP'),('pro456','Online Voting System','45 days','E-commerce','E-commerce'),('pro987','Hospital Management System','2 months','ERP','ERP');
/*!40000 ALTER TABLE `project` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-31 17:30:15
